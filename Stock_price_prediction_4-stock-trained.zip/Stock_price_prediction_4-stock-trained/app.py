from flask import Flask, render_template, request, jsonify
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import io
import base64
import requests
from keras.models import load_model
from sklearn.preprocessing import MinMaxScaler

app = Flask(__name__)

API_KEY = "cu3s1jpr01qp6s4j8k80cu3s1jpr01qp6s4j8k8g"  # Replace with your Finnhub API key

# Load trained model and scaler
model = load_model('stock_prediction_model.h5')
scaler = MinMaxScaler(feature_range=(0, 1))

# List of valid stocks
VALID_STOCKS = ["AAPL", "GOOGL", "MSFT", "AMZN"]

# Fetch live data from Finnhub API
def fetch_live_data(stock_symbol):
    if stock_symbol not in VALID_STOCKS:
        raise ValueError("Invalid stock symbol")

    url = f"https://finnhub.io/api/v1/quote?symbol={stock_symbol}&token={API_KEY}"
    response = requests.get(url)
    data = response.json()
    
    # Debugging: Print response for inspection
    print(data)
    
    if "error" in data:
        raise ValueError(f"Invalid API response: {data.get('error', 'Unexpected error occurred')}")
    
    # Finnhub returns real-time data like current price, high, low, and more. For historical data, you would need to fetch OHLC (Open, High, Low, Close) from the "historical" endpoint.
    # For simplicity, let's assume you're using the current data to predict next-day's price.
    df = pd.DataFrame([data], columns=["c", "h", "l", "o", "pc", "t"])  # Close, High, Low, Open, Previous Close, Timestamp
    df["Date"] = pd.to_datetime(df["t"], unit='s')
    df = df.drop(columns=["t"])
    df = df.rename(columns={"c": "Close", "h": "High", "l": "Low", "o": "Open", "pc": "Previous Close"})
    df.set_index("Date", inplace=True)
    
    return df

# Function to predict stock price using LSTM
def predict_stock_price(stock_symbol):
    df = fetch_live_data(stock_symbol)

    if df is None or len(df) < 60:
        raise ValueError("Insufficient data for prediction")

    # Preprocess data
    scaled_data = scaler.fit_transform(df['Close'].values.reshape(-1, 1))

    # Prepare input for LSTM (last 60 days)
    x_input = scaled_data[-60:].reshape(1, 60, 1)
    prediction = model.predict(x_input)

    # Inverse scale the prediction to get the actual price
    predicted_price = scaler.inverse_transform(prediction)

    return float(predicted_price[0][0]), df

# Plotting function
def create_plot(df, predicted_price):
    plt.figure(figsize=(10, 5))
    plt.plot(df['Close'], label='Actual Data', color='blue')
    plt.axhline(y=predicted_price, color='green', linestyle='--', label='Predicted Price')
    plt.legend()
    plt.title('Stock Price Prediction')
    plt.xlabel('Date')
    plt.ylabel('Price')
    buf = io.BytesIO()
    plt.savefig(buf, format='png')
    buf.seek(0)
    image_base64 = base64.b64encode(buf.getvalue()).decode('utf-8')
    buf.close()
    return image_base64

@app.route('/')
def index():
    return render_template('index.html', stocks=VALID_STOCKS)

@app.route('/predict', methods=['POST'])
def predict():
    data = request.get_json()  # Extract JSON data from the request
    stock_symbol = data.get('stock')

    if stock_symbol not in VALID_STOCKS:
        return jsonify({"error": "Invalid stock symbol. Only AAPL, GOOGL, MSFT, AMZN are supported."})
    
    try:
        predicted_price, df = predict_stock_price(stock_symbol)
        plot_url = create_plot(df, predicted_price)

        return jsonify({
            "plot": plot_url,
            "predicted_price": predicted_price
        })
    except ValueError as e:
        return jsonify({"error": str(e)})

if __name__ == '__main__':
    app.run(debug=True)
