import requests
import pandas as pd

# Alpha Vantage API key
API_KEY = '8XX9EZA1Z61QMLPC'

# Function to fetch stock data
def fetch_stock_data_alpha(ticker):
    url = f'https://www.alphavantage.co/query'
    params = {
        'function': 'TIME_SERIES_DAILY',  # This fetches daily stock data
        'symbol': ticker,  # Stock ticker
        'apikey': API_KEY  # Your Alpha Vantage API Key
    }
    
    # Request data from Alpha Vantage API
    response = requests.get(url, params=params)
    data = response.json()

    # Check if the API response contains the expected data
    if 'Time Series (Daily)' not in data:
        raise ValueError(f"Failed to fetch data for {ticker}. Please check the ticker symbol or API key.")
    
    # Extract time series data
    time_series = data['Time Series (Daily)']
    
    # Convert to DataFrame
    df = pd.DataFrame.from_dict(time_series, orient='index')
    df = df.astype(float)  # Convert all columns to float
    df.index = pd.to_datetime(df.index)  # Convert the index to datetime

    # Print the column names to check what we have
    print("Columns in the data:", df.columns)
    
    return df

# Example usage
ticker = 'AAPL'  # Example stock ticker for Apple
df = fetch_stock_data_alpha(ticker)

# Display the first few rows of the fetched data to see the columns and structure
print(df.head())
